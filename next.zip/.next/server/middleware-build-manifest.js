globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7dcf1880bde1ffdb.js",
    "static/chunks/a40f7e63e5487647.js",
    "static/chunks/dde55778469cc644.js",
    "static/chunks/bd47df7c63dd1e14.js",
    "static/chunks/daa85d9f6b69adb4.js",
    "static/chunks/turbopack-54e5a7fafbd36dbf.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];