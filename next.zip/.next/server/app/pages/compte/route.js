var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/pages/compte/route.js")
R.c("server/chunks/[root-of-the-server]__b15fb1c1._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_pages_compte_route_actions_0f17aaa4.js")
R.m(85484)
module.exports=R.m(85484).exports
