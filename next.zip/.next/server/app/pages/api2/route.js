var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/pages/api2/route.js")
R.c("server/chunks/[root-of-the-server]__5f09796c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_pages_api2_route_actions_a9d9b1c6.js")
R.m(5794)
module.exports=R.m(5794).exports
