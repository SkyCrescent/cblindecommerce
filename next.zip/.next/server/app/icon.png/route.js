var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_64175717.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_fa3562e2.js")
R.m(34091)
module.exports=R.m(34091).exports
