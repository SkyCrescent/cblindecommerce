module.exports=[93251,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_pages_parteners_route_actions_3b2af4e3.js.map