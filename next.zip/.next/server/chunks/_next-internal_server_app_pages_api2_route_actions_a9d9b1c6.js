module.exports=[67837,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_pages_api2_route_actions_a9d9b1c6.js.map