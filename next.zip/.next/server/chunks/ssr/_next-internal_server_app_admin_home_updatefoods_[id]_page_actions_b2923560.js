module.exports=[37271,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_home_updatefoods_%5Bid%5D_page_actions_b2923560.js.map