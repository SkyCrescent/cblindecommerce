module.exports=[59753,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_parteners_new_page_actions_e5c2edba.js.map