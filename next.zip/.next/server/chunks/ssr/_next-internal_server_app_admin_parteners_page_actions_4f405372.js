module.exports=[45505,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_parteners_page_actions_4f405372.js.map