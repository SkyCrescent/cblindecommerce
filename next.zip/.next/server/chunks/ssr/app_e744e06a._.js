module.exports=[71224,a=>{a.v("/_next/static/media/icon.1008b53e.png")},1022,a=>{"use strict";let b={src:a.i(71224).default,width:900,height:600};a.s(["default",0,b])}];

//# sourceMappingURL=app_e744e06a._.js.map