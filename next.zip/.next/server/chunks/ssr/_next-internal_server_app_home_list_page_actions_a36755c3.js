module.exports=[28068,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_home_list_page_actions_a36755c3.js.map