module.exports=[80338,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_reservation_page_actions_0dc82ee7.js.map