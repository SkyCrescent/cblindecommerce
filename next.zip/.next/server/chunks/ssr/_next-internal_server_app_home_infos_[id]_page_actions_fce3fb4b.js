module.exports=[98379,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_home_infos_%5Bid%5D_page_actions_fce3fb4b.js.map