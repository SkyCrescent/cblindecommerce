module.exports=[65900,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_home_service_%5Bid%5D_page_actions_ddbc9174.js.map