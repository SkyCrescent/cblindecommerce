module.exports=[49410,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_admin_parteners_updatecatalogue_%5Bid%5D_page_actions_25678e8f.js.map