module.exports=[59181,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_List_page_actions_ce6b5f97.js.map