module.exports=[75472,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_home_list_%5Bid%5D_page_actions_ee66cce2.js.map