module.exports=[76e3,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_stat_page_actions_54421ae9.js.map