module.exports=[730,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_compte_new_page_actions_b9b4608b.js.map