module.exports=[42619,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_compte_page_actions_06b5a6d8.js.map