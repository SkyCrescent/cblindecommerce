module.exports=[36940,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_service_page_actions_e18c1dfe.js.map