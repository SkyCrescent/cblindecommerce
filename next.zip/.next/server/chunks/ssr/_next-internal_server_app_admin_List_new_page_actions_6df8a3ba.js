module.exports=[9390,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_List_new_page_actions_6df8a3ba.js.map