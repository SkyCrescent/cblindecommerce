module.exports=[79070,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_admin_service_updatecatalogue_%5Bid%5D_page_actions_ef45edc9.js.map