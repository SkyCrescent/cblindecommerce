module.exports=[8261,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_home_reservation_page_actions_bfd72089.js.map