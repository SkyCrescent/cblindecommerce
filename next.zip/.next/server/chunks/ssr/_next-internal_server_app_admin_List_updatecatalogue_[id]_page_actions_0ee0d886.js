module.exports=[30261,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_List_updatecatalogue_%5Bid%5D_page_actions_0ee0d886.js.map