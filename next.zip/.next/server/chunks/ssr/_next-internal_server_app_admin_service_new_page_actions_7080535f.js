module.exports=[48979,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_service_new_page_actions_7080535f.js.map