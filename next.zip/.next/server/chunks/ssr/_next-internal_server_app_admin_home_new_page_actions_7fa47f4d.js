module.exports=[53019,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_home_new_page_actions_7fa47f4d.js.map